/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humana;
 
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author cande
 */
public class conexion {

    static void close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    Connection conectar=null;
    
    public Connection conectar (){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        //conectar=(Connection)DriverManager.getConnection("jdbc:mysql://localhost/humanacirugia","root",null);
        conectar=(Connection)DriverManager.getConnection("jdbc:mysql://185.211.7.138:3306/u611396439_humanadb","u611396439_humanaAdri","Humana1704.");
        JOptionPane.showMessageDialog(null,"conexión exitosa","conexión",JOptionPane.INFORMATION_MESSAGE);
    }
    catch(ClassNotFoundException| SQLException e) {
        JOptionPane.showMessageDialog(null,"Sin conexión","Conexión",JOptionPane.ERROR_MESSAGE);
        
    }
    return conectar;
    }

    }

